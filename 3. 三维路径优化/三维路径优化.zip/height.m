clear;clc;

longitude=cell2mat(struct2cell(load('longitude.mat')));
latitude=cell2mat(struct2cell(load('latitude.mat')));
elevation=cell2mat(struct2cell(load('elevation.mat')));

height_ = zeros(200,300);

 for i = 1:(size(elevation,1))
     row = BinarySearch_2(latitude,1,200,abs(elevation(i,3)));
     column = BinarySearch_2(longitude,1,300,elevation(i,4));
     for j=1:10
         for k=1:10
             height_(row+j,column+k) = elevation(i,2);
         end
     end    
 end
 
 save('height.mat','height_');
 writematrix(height_,'height.csv');
     