function y_a=pre_linear(level,row,column,array,array_n)
t1 = 2000:2019;
t2 = 2000:2029;
t3=linspace(2000,2019,size(array_n,2));
p_a = polyfit(t3,array_n,1);
y_a = polyval(p_a,t2);

plot(t1, array,'r.'); hold on;
plot(t2, y_a, 'b-');
xlabel('year'); ylabel('number of fires per year');
legend('actual number','number of prediction without abnormal data');
title('forcast chart of number of fires');
grid on;
saveas(gca,strcat('�ȼ�',num2str(level),'����',num2str(row),'��',num2str(column),'���Ż�Ԥ��ͼ.png'));
hold off;