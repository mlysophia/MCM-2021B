clear;clc;

firetimes_stat=cell2mat(struct2cell(load('firetimes_stat.mat')));

i=1;
j=106;

array=zeros(1,20);
for k=1:20
    array(k)=firetimes_stat(i,300*(k-1)+j);
end
array_n = rmoutliers(array);

array
array_n

t1 = 2000:2019;
t2 = 2000:2029;
p_b = polyfit(t1,array,1);
y_b = polyval(p_b,t2);
t3=linspace(2000,2019,size(array_n,2));
p_a = polyfit(t3,array_n,1);
y_a = polyval(p_a,t2);

plot(t1, array,'r.'); hold on;
plot(t2, y_b, 'g-');hold on;
plot(t2, y_a, 'b-');
xlabel('year'); ylabel('number of fires per year');
legend('actual number','number of prediction with abnormal data','number of prediction without abnormal data');
title('forcast chart of number of fires');
grid on;
saveas(gca,'contrast.png');
hold off;